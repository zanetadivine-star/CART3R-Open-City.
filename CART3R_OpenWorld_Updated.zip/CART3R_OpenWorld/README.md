# CART3R: OPEN CITY 2.0 — Android project

Original top-down open-city driving prototype. It is not GTA 6 and contains no Rockstar assets or code.

## Gameplay
- Player car with steering, acceleration, brake/reverse and nitro
- Procedurally tiled city blocks and parks
- Ambient traffic and wandering pedestrians
- Police pursuit / wanted level
- Five sequential checkpoint missions and cash rewards
- Vehicle health and respawn
- Landscape touch controls

## Build locally
Open this folder in Android Studio (JDK 17, Android SDK 35), then build the `debug` variant.

## Build from an Android phone using GitHub Actions
1. Create a new GitHub repository.
2. Upload this ZIP file to the repository root with the exact name `CART3R_OpenWorld_Updated.zip`.
3. Also add the workflow file at `.github/workflows/android.yml` using the workflow included in this project (or upload that file at the matching path).
4. Open the repository's **Actions** tab and run **Build CART3R Open City APK** (or wait for the push workflow).
5. When the workflow succeeds, open its run, scroll to **Artifacts**, and download `CART3R-Open-City-debug-APK`.
6. Extract the artifact ZIP on your phone, tap the `.apk`, and follow Android's install prompt. Android may ask you to allow your browser or Files app to install unknown apps.

The debug APK is for personal testing. It is not a Play Store release.

## Technical
- Kotlin Android Canvas prototype
- AGP 8.7.3 / Kotlin 2.0.21
- compileSdk 35 / minSdk 23 / Java 17
