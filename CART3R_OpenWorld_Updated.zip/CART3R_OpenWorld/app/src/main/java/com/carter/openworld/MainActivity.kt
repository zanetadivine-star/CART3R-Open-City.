package com.carter.openworld

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.*
import kotlin.random.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
             View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        setContentView(CityGameView())
    }
}

private data class TrafficCar(var x: Float, var y: Float, var angle: Float, val color: Int, var speed: Float)
private data class Pedestrian(var x: Float, var y: Float, var direction: Float, val shirt: Int, var timer: Float)
private data class PoliceCar(var x: Float, var y: Float, var angle: Float, var speed: Float = 0f)

private class CityGameView : View() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rng = Random(42)
    private var carX = 0f
    private var carY = 0f
    private var angle = -PI.toFloat() / 2f
    private var speed = 0f
    private var gas = false
    private var brake = false
    private var nitro = false
    private var steer = 0f
    private var horn = false
    private var health = 100f
    private var cash = 0
    private var wanted = 0
    private var missionIndex = 0
    private var missionFlash = 0f
    private var collisionCooldown = 0f
    private var lastTime = System.nanoTime()
    private var elapsed = 0f
    private val road = 360f
    private val block = 660f
    private val span = road + block
    private val traffic = mutableListOf<TrafficCar>()
    private val pedestrians = mutableListOf<Pedestrian>()
    private val police = mutableListOf<PoliceCar>()
    private val missionPoints = listOf(
        Pair(1100f, -900f), Pair(2100f, 1050f), Pair(-1200f, 1750f),
        Pair(-2300f, -1400f), Pair(0f, 0f)
    )
    private val missionNames = listOf("FIRST PICKUP", "DOWNTOWN RUN", "HARBOR DELIVERY", "NIGHT SHIFT", "HOME STRETCH")
    private val carColors = intArrayOf(
        Color.rgb(225, 180, 62), Color.rgb(65, 150, 190), Color.rgb(220, 220, 215),
        Color.rgb(90, 170, 105), Color.rgb(155, 105, 185), Color.rgb(190, 75, 60)
    )

    init {
        isFocusable = true
        repeat(18) {
            val horizontal = rng.nextBoolean()
            val lane = if (rng.nextBoolean()) 105f else 255f
            val gx = rng.nextInt(-5, 6) * span
            val gy = rng.nextInt(-5, 6) * span
            traffic.add(
                if (horizontal) TrafficCar(gx + rng.nextFloat() * 900f, gy + lane, if (rng.nextBoolean()) 0f else PI.toFloat(), carColors.random(rng), 90f + rng.nextFloat() * 90f)
                else TrafficCar(gx + lane, gy + rng.nextFloat() * 900f, if (rng.nextBoolean()) PI.toFloat() / 2f else -PI.toFloat() / 2f, carColors.random(rng), 90f + rng.nextFloat() * 90f)
            )
        }
        repeat(30) {
            pedestrians.add(
                Pedestrian(
                    rng.nextInt(-2400, 2400).toFloat(), rng.nextInt(-2400, 2400).toFloat(),
                    rng.nextFloat() * 6.28f, carColors.random(rng), rng.nextFloat() * 3f
                )
            )
        }
    }

    private fun fill(c: Int) { paint.color = c; paint.style = Paint.Style.FILL; paint.alpha = 255 }
    private fun rect(c: Canvas, x: Float, y: Float, w: Float, h: Float, col: Int, radius: Float = 0f) {
        fill(col); c.drawRoundRect(x, y, x + w, y + h, radius, radius, paint)
    }
    private fun circle(c: Canvas, x: Float, y: Float, r: Float, col: Int) {
        fill(col); c.drawCircle(x, y, r, paint)
    }
    private fun text(c: Canvas, value: String, x: Float, y: Float, size: Float, col: Int, bold: Boolean = false) {
        fill(col); paint.textSize = size
        paint.typeface = if (bold) Typeface.create("sans-serif", Typeface.BOLD) else Typeface.create("sans-serif", Typeface.NORMAL)
        c.drawText(value, x, y, paint)
    }
    private fun screenX(worldX: Float, cameraX: Float, width: Float) = worldX - cameraX + width / 2f
    private fun screenY(worldY: Float, cameraY: Float, height: Float) = worldY - cameraY + height / 2f

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = System.nanoTime()
        val dt = ((now - lastTime) / 1_000_000_000f).coerceIn(0f, 0.04f)
        lastTime = now
        elapsed += dt
        update(dt)
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawColor(Color.rgb(28, 54, 45))
        val cameraX = carX
        val cameraY = carY
        drawCity(canvas, w, h, cameraX, cameraY)
        drawMission(canvas, w, h, cameraX, cameraY)
        drawPedestrians(canvas, w, h, cameraX, cameraY)
        drawTraffic(canvas, w, h, cameraX, cameraY)
        drawPolice(canvas, w, h, cameraX, cameraY)
        drawPlayerCar(canvas, w, h)
        drawHud(canvas, w, h)
        postInvalidateDelayed(16)
    }

    private fun drawCity(c: Canvas, w: Float, h: Float, camX: Float, camY: Float) {
        val minGX = floor((camX - w / 2f - span) / span).toInt()
        val maxGX = ceil((camX + w / 2f + span) / span).toInt()
        val minGY = floor((camY - h / 2f - span) / span).toInt()
        val maxGY = ceil((camY + h / 2f + span) / span).toInt()
        for (gx in minGX..maxGX) {
            val x = gx * span - camX + w / 2f
            rect(c, x, 0f, road, h, Color.rgb(54, 59, 65))
            rect(c, x + road / 2f - 3f, 0f, 6f, h, Color.rgb(190, 174, 115))
            var yy = 0f
            while (yy < h) {
                rect(c, x + 18f, yy + 20f, 24f, 42f, Color.rgb(215, 207, 170))
                yy += 95f
            }
        }
        for (gy in minGY..maxGY) {
            val y = gy * span - camY + h / 2f
            rect(c, 0f, y, w, road, Color.rgb(54, 59, 65))
            rect(c, 0f, y + road / 2f - 3f, w, 6f, Color.rgb(190, 174, 115))
            var xx = 0f
            while (xx < w) {
                rect(c, xx + 20f, y + 18f, 42f, 24f, Color.rgb(215, 207, 170))
                xx += 95f
            }
        }
        for (gx in minGX - 1..maxGX + 1) for (gy in minGY - 1..maxGY + 1) {
            val left = gx * span + road - camX + w / 2f
            val top = gy * span + road - camY + h / 2f
            val seed = abs(gx * 31 + gy * 17)
            if (seed % 5 == 0) {
                rect(c, left + 35f, top + 35f, block - 70f, block - 70f, Color.rgb(43, 105, 70), 18f)
                for (i in 0..8) {
                    val tx = left + 75f + (i % 3) * 165f
                    val ty = top + 80f + (i / 3) * 160f
                    circle(c, tx, ty, 28f, Color.rgb(28, 76, 51))
                    circle(c, tx - 5f, ty - 6f, 20f, Color.rgb(79, 139, 79))
                }
            } else {
                rect(c, left + 35f, top + 35f, block - 70f, block - 70f, Color.rgb(83, 75, 72), 12f)
                val bx = left + 65f
                val by = top + 65f
                val buildingColor = if (seed % 2 == 0) Color.rgb(126, 105, 91) else Color.rgb(105, 112, 119)
                rect(c, bx, by, block - 130f, block - 130f, buildingColor, 8f)
                for (i in 0..3) for (j in 0..3) {
                    rect(c, bx + 30f + i * 105f, by + 30f + j * 105f, 38f, 30f, Color.rgb(174, 177, 165), 3f)
                }
            }
        }
    }

    private fun drawMission(c: Canvas, w: Float, h: Float, camX: Float, camY: Float) {
        val point = missionPoints[missionIndex]
        val x = screenX(point.first, camX, w)
        val y = screenY(point.second, camY, h)
        circle(c, x, y, 38f + 5f * sin(elapsed * 3f), Color.argb(65, 255, 190, 55))
        circle(c, x, y, 25f, Color.rgb(255, 190, 55))
        circle(c, x, y, 9f, Color.WHITE)
    }

    private fun drawPedestrians(c: Canvas, w: Float, h: Float, camX: Float, camY: Float) {
        pedestrians.forEach { person ->
            val x = screenX(person.x, camX, w)
            val y = screenY(person.y, camY, h)
            if (x in -20f..w + 20f && y in -20f..h + 20f) {
                circle(c, x, y, 7f, person.shirt)
                circle(c, x, y - 7f, 4f, Color.rgb(220, 180, 145))
            }
        }
    }

    private fun drawVehicle(c: Canvas, x: Float, y: Float, rotation: Float, body: Int, policeCar: Boolean = false) {
        c.save()
        c.translate(x, y)
        c.rotate(Math.toDegrees(rotation.toDouble()).toFloat() + 90f)
        rect(c, -15f, -27f, 30f, 54f, body, 7f)
        rect(c, -11f, -17f, 22f, 17f, Color.rgb(105, 171, 190), 4f)
        rect(c, -11f, 7f, 22f, 12f, Color.rgb(43, 50, 57), 3f)
        rect(c, -18f, -18f, 5f, 13f, Color.BLACK, 2f)
        rect(c, 13f, -18f, 5f, 13f, Color.BLACK, 2f)
        if (policeCar) {
            rect(c, -12f, -3f, 11f, 5f, Color.rgb(65, 150, 255), 2f)
            rect(c, 1f, -3f, 11f, 5f, Color.rgb(255, 50, 60), 2f)
        }
        c.restore()
    }

    private fun drawTraffic(c: Canvas, w: Float, h: Float, camX: Float, camY: Float) {
        traffic.forEach {
            val x = screenX(it.x, camX, w)
            val y = screenY(it.y, camY, h)
            if (x in -60f..w + 60f && y in -60f..h + 60f) drawVehicle(c, x, y, it.angle, it.color)
        }
    }
    private fun drawPolice(c: Canvas, w: Float, h: Float, camX: Float, camY: Float) {
        police.forEach {
            val x = screenX(it.x, camX, w)
            val y = screenY(it.y, camY, h)
            if (x in -60f..w + 60f && y in -60f..h + 60f) drawVehicle(c, x, y, it.angle, Color.rgb(28, 34, 44), true)
        }
    }
    private fun drawPlayerCar(c: Canvas, w: Float, h: Float) {
        drawVehicle(c, w / 2f, h / 2f, angle, Color.rgb(195, 35, 52))
    }

    private fun update(dt: Float) {
        if (gas) speed = (speed + dt * 245f).coerceAtMost(if (nitro) 560f else 390f) else speed *= 0.987f
        if (brake) speed = (speed - dt * 470f).coerceAtLeast(-95f)
        if (nitro && gas) speed = (speed + dt * 190f).coerceAtMost(560f)
        if (abs(speed) < 1f) speed = 0f
        angle += steer * (speed / 390f).coerceIn(-0.5f, 1f) * dt * 2.65f
        carX += cos(angle) * speed * dt
        carY += sin(angle) * speed * dt
        collisionCooldown = (collisionCooldown - dt).coerceAtLeast(0f)
        missionFlash = (missionFlash - dt).coerceAtLeast(0f)

        traffic.forEach { car ->
            car.x += cos(car.angle) * car.speed * dt
            car.y += sin(car.angle) * car.speed * dt
            if (hypot(carX - car.x, carY - car.y) < 43f && collisionCooldown <= 0f) {
                speed *= -0.35f
                health = (health - 8f).coerceAtLeast(0f)
                wanted = (wanted + 1).coerceAtMost(5)
                collisionCooldown = 1.1f
            }
        }
        pedestrians.forEach { person ->
            person.timer -= dt
            if (person.timer <= 0f) {
                person.direction += (rng.nextFloat() - 0.5f) * 2f
                person.timer = 1.5f + rng.nextFloat() * 3f
            }
            person.x += cos(person.direction) * 17f * dt
            person.y += sin(person.direction) * 17f * dt
            if (hypot(carX - person.x, carY - person.y) < 30f && abs(speed) > 100f && collisionCooldown <= 0f) {
                wanted = (wanted + 1).coerceAtMost(5)
                health = (health - 5f).coerceAtLeast(0f)
                collisionCooldown = 1.1f
            }
        }
        if (wanted > 0 && police.size < min(1 + wanted, 5) && elapsed % 5f < dt) {
            val spawnAngle = rng.nextFloat() * 6.28f
            police.add(PoliceCar(carX + cos(spawnAngle) * 620f, carY + sin(spawnAngle) * 620f, spawnAngle + PI.toFloat()))
        }
        val policeIterator = police.iterator()
        while (policeIterator.hasNext()) {
            val cop = policeIterator.next()
            val target = atan2(carY - cop.y, carX - cop.x)
            var delta = ((target - cop.angle + PI.toFloat()) % (2f * PI.toFloat())) - PI.toFloat()
            cop.angle += delta.coerceIn(-dt * 1.7f, dt * 1.7f)
            cop.speed = (cop.speed + dt * 100f).coerceAtMost(205f)
            cop.x += cos(cop.angle) * cop.speed * dt
            cop.y += sin(cop.angle) * cop.speed * dt
            if (hypot(carX - cop.x, carY - cop.y) < 48f && collisionCooldown <= 0f) {
                health = (health - 12f).coerceAtLeast(0f)
                speed *= 0.55f
                collisionCooldown = 1.2f
            }
            if (wanted == 0 && hypot(carX - cop.x, carY - cop.y) > 900f) policeIterator.remove()
        }
        if (wanted > 0 && elapsed % 18f < dt && police.isEmpty()) wanted = (wanted - 1).coerceAtLeast(0)

        val destination = missionPoints[missionIndex]
        if (hypot(carX - destination.first, carY - destination.second) < 95f) {
            cash += 250
            missionIndex = (missionIndex + 1) % missionPoints.size
            missionFlash = 3f
        }
        if (health <= 0f) {
            health = 100f
            speed = 0f
            wanted = 0
            police.clear()
            cash = (cash - 100).coerceAtLeast(0)
        }
    }

    private fun drawHud(c: Canvas, w: Float, h: Float) {
        rect(c, 14f, 14f, 250f, 104f, Color.argb(220, 8, 10, 14), 13f)
        text(c, "CART3R  /  OPEN CITY", 28f, 40f, 16f, Color.WHITE, true)
        text(c, "SPEED  ${abs(speed).toInt()} KM/H", 28f, 65f, 13f, Color.rgb(255, 105, 120), true)
        text(c, "CASH  \$${cash}", 28f, 88f, 12f, Color.rgb(100, 220, 155), true)
        rect(c, 28f, 96f, 205f, 8f, Color.rgb(65, 35, 42), 4f)
        rect(c, 28f, 96f, 205f * health / 100f, 8f, Color.rgb(220, 65, 75), 4f)

        rect(c, w - 252f, 14f, 238f, 88f, Color.argb(220, 8, 10, 14), 13f)
        text(c, "MISSION ${missionIndex + 1}/${missionPoints.size}", w - 235f, 39f, 12f, Color.LTGRAY, true)
        text(c, missionNames[missionIndex], w - 235f, 61f, 14f, Color.rgb(255, 205, 91), true)
        text(c, "WANTED  " + "★".repeat(wanted) + "☆".repeat(5 - wanted), w - 235f, 84f, 14f, Color.rgb(255, 90, 95), true)
        if (missionFlash > 0f) {
            rect(c, w / 2f - 145f, 125f, 290f, 48f, Color.argb(220, 12, 38, 25), 12f)
            text(c, "MISSION COMPLETE  +\$250", w / 2f - 120f, 155f, 16f, Color.rgb(110, 245, 155), true)
        }
        drawButton(c, 65f, h - 88f, 48f, "◀")
        drawButton(c, 174f, h - 88f, 48f, "▶")
        drawButton(c, w - 78f, h - 88f, 54f, "GAS")
        drawButton(c, w - 185f, h - 88f, 54f, "BRAKE")
        drawButton(c, w - 78f, h - 190f, 43f, "N₂O")
        text(c, "HOLD CONTROLS TO DRIVE", 22f, h - 157f, 10f, Color.WHITE, true)
    }

    private fun drawButton(c: Canvas, x: Float, y: Float, radius: Float, label: String) {
        circle(c, x, y, radius, Color.argb(175, 12, 15, 21))
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.color = Color.argb(230, 255, 65, 85)
        c.drawCircle(x, y, radius, paint)
        paint.style = Paint.Style.FILL
        paint.color = Color.WHITE
        paint.textSize = if (label.length > 3) 13f else 23f
        paint.textAlign = Paint.Align.CENTER
        c.drawText(label, x, y + 6f, paint)
        paint.textAlign = Paint.Align.LEFT
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val h = height.toFloat()
        val w = width.toFloat()
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_MOVE -> {
                gas = false; brake = false; nitro = false; steer = 0f
                for (i in 0 until event.pointerCount) {
                    val x = event.getX(i)
                    val y = event.getY(i)
                    if (y > h - 145f) {
                        if (x < 120f) steer = -1f
                        else if (x < 235f) steer = 1f
                        else if (x > w - 135f) gas = true
                        else if (x > w - 245f) brake = true
                    } else if (x > w - 145f && y > h - 255f && y < h - 130f) {
                        nitro = true
                    }
                }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                gas = false; brake = false; nitro = false; steer = 0f
            }
        }
        return true
    }
}
